import { type UserUsage, type TokenUsage, calculateCost } from "./admin"

// In-memory storage for demo (replace with database in production)
const userUsageData: Record<string, UserUsage> = {
  // Add some dummy data to demonstrate the admin panel
  "demo-user": {
    userId: "demo-user",
    email: "demo@radimpression.com",
    displayName: "Dr. Demo User",
    totalTokensUsed: 15420,
    totalImpressions: 23,
    isBlocked: false,
    lastUsed: new Date(),
    createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), // 7 days ago
    tokensToday: 2340,
    impressionsToday: 3,
    lastResetDate: new Date(),
  },
  "user-2": {
    userId: "user-2",
    email: "dr.smith@hospital.com",
    displayName: "Dr. Sarah Smith",
    totalTokensUsed: 45230,
    totalImpressions: 67,
    isBlocked: false,
    lastUsed: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
    createdAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000), // 14 days ago
    tokensToday: 5670,
    impressionsToday: 8,
    lastResetDate: new Date(),
  },
  "user-3": {
    userId: "user-3",
    email: "dr.johnson@clinic.org",
    displayName: "Dr. Michael Johnson",
    totalTokensUsed: 89450,
    totalImpressions: 134,
    isBlocked: true, // This user is blocked
    lastUsed: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
    createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
    tokensToday: 0,
    impressionsToday: 0,
    lastResetDate: new Date(),
  },
  "user-4": {
    userId: "user-4",
    email: "dr.wilson@medical.edu",
    displayName: "Dr. Emily Wilson",
    totalTokensUsed: 23890,
    totalImpressions: 45,
    isBlocked: false,
    lastUsed: new Date(Date.now() - 30 * 60 * 1000), // 30 minutes ago
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
    tokensToday: 3420,
    impressionsToday: 5,
    lastResetDate: new Date(),
  },
}

const blockedUsers: Set<string> = new Set(["user-3"]) // Pre-block user-3

export const trackTokenUsage = async (
  userId: string,
  email: string,
  displayName: string,
  tokenUsage: TokenUsage,
  model = "gpt-4o",
) => {
  const now = new Date()
  const today = now.toDateString()

  // Initialize user if not exists
  if (!userUsageData[userId]) {
    userUsageData[userId] = {
      userId,
      email,
      displayName,
      totalTokensUsed: 0,
      totalImpressions: 0,
      isBlocked: false,
      lastUsed: now,
      createdAt: now,
      tokensToday: 0,
      impressionsToday: 0,
      lastResetDate: now,
    }
  }

  const user = userUsageData[userId]

  // Reset daily counters if new day
  if (user.lastResetDate.toDateString() !== today) {
    user.tokensToday = 0
    user.impressionsToday = 0
    user.lastResetDate = now
  }

  // Update usage
  user.totalTokensUsed += tokenUsage.totalTokens
  user.totalImpressions += 1
  user.tokensToday += tokenUsage.totalTokens
  user.impressionsToday += 1
  user.lastUsed = now

  // Calculate cost
  const cost = calculateCost(tokenUsage, model)

  console.log(`Token usage tracked for ${email}:`, {
    tokens: tokenUsage.totalTokens,
    cost: `$${cost.toFixed(4)}`,
    totalTokens: user.totalTokensUsed,
    totalImpressions: user.totalImpressions,
  })

  return user
}

export const isUserBlocked = (userId: string): boolean => {
  return blockedUsers.has(userId) || userUsageData[userId]?.isBlocked || false
}

export const blockUser = (userId: string): void => {
  blockedUsers.add(userId)
  if (userUsageData[userId]) {
    userUsageData[userId].isBlocked = true
  }
}

export const unblockUser = (userId: string): void => {
  blockedUsers.delete(userId)
  if (userUsageData[userId]) {
    userUsageData[userId].isBlocked = false
  }
}

export const getAllUsers = (): UserUsage[] => {
  return Object.values(userUsageData).sort((a, b) => new Date(b.lastUsed).getTime() - new Date(a.lastUsed).getTime())
}

export const getUserUsage = (userId: string): UserUsage | null => {
  return userUsageData[userId] || null
}

// History tracking
export interface ImpressionHistory {
  id: string
  userId: string
  findings: string
  impression: string
  tokenUsage: TokenUsage
  createdAt: Date
  model: string
}

const impressionHistory: ImpressionHistory[] = [
  // Dummy history data
  {
    id: "hist-1",
    userId: "demo-user",
    findings:
      "Chest X-ray shows clear lung fields bilaterally. No acute cardiopulmonary abnormalities. Heart size within normal limits.",
    impression: "IMPRESSION: Normal chest X-ray. No acute cardiopulmonary abnormalities identified.",
    tokenUsage: { promptTokens: 45, completionTokens: 28, totalTokens: 73, cost: 0.0012 },
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
    model: "gpt-4o",
  },
  {
    id: "hist-2",
    userId: "demo-user",
    findings: "CT abdomen shows mild hepatomegaly. No focal lesions identified. Gallbladder appears normal.",
    impression: "IMPRESSION: Mild hepatomegaly without focal lesions. Clinical correlation recommended.",
    tokenUsage: { promptTokens: 52, completionTokens: 35, totalTokens: 87, cost: 0.0015 },
    createdAt: new Date(Date.now() - 24 * 60 * 60 * 1000), // 1 day ago
    model: "gpt-4o",
  },
  {
    id: "hist-3",
    userId: "demo-user",
    findings: "MRI brain shows no acute intracranial abnormalities. White matter appears normal for age.",
    impression: "IMPRESSION: Normal MRI brain. No acute intracranial abnormalities.",
    tokenUsage: { promptTokens: 48, completionTokens: 25, totalTokens: 73, cost: 0.0011 },
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000), // 3 days ago
    model: "gpt-4o",
  },
]

export const getUserHistory = (userId: string): ImpressionHistory[] => {
  return impressionHistory
    .filter((item) => item.userId === userId)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
}

export const addToHistory = (
  userId: string,
  findings: string,
  impression: string,
  tokenUsage: TokenUsage,
  model = "gpt-4o",
): void => {
  const historyItem: ImpressionHistory = {
    id: `hist-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    userId,
    findings,
    impression,
    tokenUsage,
    createdAt: new Date(),
    model,
  }

  impressionHistory.push(historyItem)
}
