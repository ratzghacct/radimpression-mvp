import { type NextRequest, NextResponse } from "next/server"
import { trackTokenUsage, isUserBlocked, addToHistory } from "@/lib/usage-tracker"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    console.log("API received body:", body)

    const { findings, userId, userEmail, userName } = body

    // More detailed validation
    if (!findings || typeof findings !== "string" || !findings.trim()) {
      console.log("Missing or invalid findings:", findings)
      return NextResponse.json({ error: "Findings are required and must be a non-empty string" }, { status: 400 })
    }

    if (!userId || typeof userId !== "string") {
      console.log("Missing or invalid userId:", userId)
      return NextResponse.json({ error: "User ID is required" }, { status: 400 })
    }

    console.log("Validation passed. Processing request for user:", userId)

    // Check if user is blocked
    if (isUserBlocked(userId)) {
      console.log("User is blocked:", userId)
      return NextResponse.json(
        {
          error: "Account temporarily suspended. Please contact support.",
          blocked: true,
        },
        { status: 403 },
      )
    }

    // REAL OpenAI API Integration (uncomment when ready)
    /*
    const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: 'You are a professional radiologist. Provide accurate, professional impressions based on radiology findings.'
          },
          {
            role: 'user',
            content: `Please provide a professional radiology impression based on these findings: ${findings}`
          }
        ],
        max_tokens: 500,
        temperature: 0.3,
      }),
    })

    const openaiData = await openaiResponse.json()
    
    const impression = openaiData.choices[0].message.content
    const usage = openaiData.usage
    */

    // Mock response for now (replace with above when ready)
    const prompt = `As a radiologist, provide a professional impression based on these findings: ${findings}`
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const mockResponse = {
      impression: `Based on the provided findings, the imaging demonstrates:

• ${findings.split(".")[0] || findings}
• No acute abnormalities identified in the visualized structures
• Recommend clinical correlation and follow-up as clinically indicated

IMPRESSION: ${findings.includes("normal") || findings.includes("clear") ? "Normal study" : "Findings as described above"}. Clinical correlation recommended.`,
      usage: {
        promptTokens: Math.floor(prompt.length / 4),
        completionTokens: 85,
        totalTokens: Math.floor(prompt.length / 4) + 85,
      },
    }

    const cost = (mockResponse.usage.promptTokens * 0.0025 + mockResponse.usage.completionTokens * 0.01) / 1000

    const tokenUsage = {
      promptTokens: mockResponse.usage.promptTokens,
      completionTokens: mockResponse.usage.completionTokens,
      totalTokens: mockResponse.usage.totalTokens,
      cost,
    }

    console.log("Generated impression successfully")

    // Track token usage
    await trackTokenUsage(userId, userEmail || "unknown@email.com", userName || "Unknown User", tokenUsage)

    // Add to history
    addToHistory(userId, findings, mockResponse.impression, tokenUsage)

    return NextResponse.json({
      impression: mockResponse.impression,
      tokenUsage: mockResponse.usage,
      cost: cost.toFixed(4),
    })
  } catch (error) {
    console.error("Error generating impression:", error)
    return NextResponse.json({ error: "Failed to generate impression" }, { status: 500 })
  }
}
