import { type NextRequest, NextResponse } from "next/server"
import { getAllUsers } from "@/lib/usage-tracker"
import { isAdmin } from "@/lib/admin"

export async function GET(request: NextRequest) {
  try {
    // Get user email from headers
    const userEmail = request.headers.get("x-user-email")

    console.log("=== ADMIN API DEBUG ===")
    console.log("Request headers:", Object.fromEntries(request.headers.entries()))
    console.log("User email from header:", userEmail)
    console.log("Is admin check result:", isAdmin(userEmail))
    console.log("=====================")

    if (!userEmail) {
      return NextResponse.json(
        {
          error: "No user email provided in headers",
          received: userEmail,
        },
        { status: 400 },
      )
    }

    if (!isAdmin(userEmail)) {
      return NextResponse.json(
        {
          error: "Unauthorized - Admin access required",
          email: userEmail,
          isAdmin: false,
        },
        { status: 403 },
      )
    }

    const users = getAllUsers()
    console.log("Returning users:", users.length)

    return NextResponse.json({
      users,
      debug: {
        adminEmail: userEmail,
        userCount: users.length,
        timestamp: new Date().toISOString(),
      },
    })
  } catch (error) {
    console.error("Error in admin API:", error)
    return NextResponse.json(
      {
        error: "Internal server error",
        details: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
