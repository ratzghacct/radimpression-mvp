"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import {
  Stethoscope,
  ArrowLeft,
  Sparkles,
  Copy,
  RefreshCw,
  Activity,
  History,
  Clock,
  Search,
  FileText,
  CreditCard,
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  List,
  ListOrdered,
  AlertTriangle,
} from "lucide-react"
import { useAuth } from "@/contexts/auth-context"
import { isAdmin } from "@/lib/admin"
import { toast } from "@/hooks/use-toast"
import { PricingSection } from "@/components/pricing-section"
import { PricingPopup } from "@/components/pricing-popup"

interface ImpressionHistory {
  id: string
  userId: string
  findings: string
  impression: string
  tokenUsage: {
    promptTokens: number
    completionTokens: number
    totalTokens: number
    cost: number
  }
  createdAt: Date
  model: string
}

export default function ImpressionPage() {
  const [findings, setFindings] = useState("")
  const [impression, setImpression] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [tokenUsage, setTokenUsage] = useState<any>(null)
  const [history, setHistory] = useState<ImpressionHistory[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [activeTab, setActiveTab] = useState("generate")
  const [showPricingPopup, setShowPricingPopup] = useState(false)
  const [lastGeneratedAt, setLastGeneratedAt] = useState<Date | null>(null)
  const [showPricing, setShowPricing] = useState(false)
  const [selectedText, setSelectedText] = useState("")
  const { user } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!user) {
      router.push("/login")
      return
    }
    fetchHistory()
  }, [user, router])

  const fetchHistory = async () => {
    try {
      const userId = user?.uid || user?.id || "demo-user"
      const response = await fetch("/api/history", {
        headers: {
          "x-user-id": userId,
        },
      })

      if (response.ok) {
        const data = await response.json()
        setHistory(data.history)
      }
    } catch (error) {
      console.error("Error fetching history:", error)
    }
  }

  const generateImpression = async () => {
    if (!findings.trim()) {
      toast({
        title: "Missing Findings",
        description: "Please enter your radiology findings first.",
        variant: "destructive",
      })
      return
    }

    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please log in to generate impressions.",
        variant: "destructive",
      })
      return
    }

    // Get user ID - handle both Firebase and demo users
    const userId = user.uid || user.id || "demo-user"
    const userEmail = user.email || "demo@radimpression.com"
    const userName = user.displayName || user.name || "Demo User"

    if (!userId) {
      toast({
        title: "Authentication Error",
        description: "Unable to identify user. Please try logging in again.",
        variant: "destructive",
      })
      return
    }

    setIsGenerating(true)
    setImpression("")
    setTokenUsage(null)

    try {
      const response = await fetch("/api/generate-impression", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          findings: findings.trim(),
          userId: userId,
          userEmail: userEmail,
          userName: userName,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        if (data.blocked) {
          setShowPricingPopup(true)
          toast({
            title: "Account Suspended",
            description: "Your account has reached its usage limit. Please upgrade to continue.",
            variant: "destructive",
          })
          return
        }
        throw new Error(data.error || "Failed to generate impression")
      }

      setImpression(data.impression)
      setTokenUsage(data.tokenUsage)
      setLastGeneratedAt(new Date())

      // Refresh history after generating
      fetchHistory()

      toast({
        title: "Impression Generated!",
        description: `Used ${data.tokenUsage.totalTokens} tokens`,
      })
    } catch (error: any) {
      console.error("Error:", error)
      toast({
        title: "Generation Failed",
        description: error.message || "Failed to generate impression. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(false)
    }
  }

  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      toast({
        title: "Copied!",
        description: "Impression copied to clipboard",
      })
    } catch (error) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy to clipboard",
        variant: "destructive",
      })
    }
  }

  const formatText = (format: string) => {
    const textArea = document.getElementById("impression-text") as HTMLTextAreaElement
    if (!textArea) return

    const start = textArea.selectionStart
    const end = textArea.selectionEnd
    const selectedText = impression.substring(start, end)

    if (selectedText) {
      let formattedText = selectedText

      switch (format) {
        case "Bold":
          formattedText = `**${selectedText}**`
          break
        case "Italic":
          formattedText = `*${selectedText}*`
          break
        case "Underline":
          formattedText = `__${selectedText}__`
          break
        case "Bullet List":
          formattedText = selectedText
            .split("\n")
            .map((line) => (line.trim() ? `• ${line}` : line))
            .join("\n")
          break
        case "Numbered List":
          formattedText = selectedText
            .split("\n")
            .map((line, index) => (line.trim() ? `${index + 1}. ${line}` : line))
            .join("\n")
          break
        default:
          break
      }

      const newImpression = impression.substring(0, start) + formattedText + impression.substring(end)
      setImpression(newImpression)

      toast({
        title: "Text Formatted",
        description: `${format} formatting applied to selected text`,
      })
    } else {
      toast({
        title: "No Text Selected",
        description: "Please select text in the impression area to format",
        variant: "destructive",
      })
    }
  }

  const filteredHistory = history.filter(
    (item) =>
      item.findings.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.impression.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" onClick={() => router.push("/")} className="text-gray-600 hover:text-gray-900 p-2">
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center">
                <Stethoscope className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">AI Impression Generator</h1>
                <p className="text-gray-600">Generate professional radiology impressions with AI</p>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            {/* Pricing Button - Separate and Highlighted */}
            <Button
              onClick={() => setShowPricing(!showPricing)}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-6 py-2 rounded-lg shadow-lg"
            >
              <CreditCard className="w-4 h-4 mr-2" />
              View Pricing
            </Button>

            {/* Show admin button only for actual admins */}
            {isAdmin(user.email) && (
              <Button
                variant="outline"
                onClick={() => router.push("/admin")}
                className="text-blue-600 border-blue-600 hover:bg-blue-50"
              >
                Admin Panel
              </Button>
            )}
            <Badge className="bg-blue-100 text-blue-700">
              <Activity className="w-4 h-4 mr-1" />
              {user.displayName || user.email}
            </Badge>
          </div>
        </div>

        {/* Disclaimer - Always Visible */}
        <Card className="mb-6 border-amber-200 bg-amber-50">
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
              <div className="text-xs text-amber-800 leading-relaxed">
                <strong>Disclaimer:</strong> The impressions generated by this tool are powered by AI based on the input
                findings provided by the user. These outputs are intended for assistance and productivity enhancement
                only.
                <br />
                <br />
                They are not a substitute for professional medical judgment, diagnosis, or decision-making. Users must
                independently verify all AI-generated content before using it in any official medical documentation,
                communication, or reporting.
                <br />
                <br />
                The tool's developers disclaim all liability for clinical use, interpretation errors, or patient
                outcomes resulting from reliance on AI-generated impressions.
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Pricing Section - Conditional Display */}
        {showPricing && (
          <div className="mb-8">
            <Card className="border-2 border-blue-200 shadow-xl">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-2xl text-blue-900">Pricing Plans</CardTitle>
                  <Button variant="ghost" onClick={() => setShowPricing(false)} className="text-gray-500">
                    ✕
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <PricingSection />
              </CardContent>
            </Card>
          </div>
        )}

        {/* Main Content - Only Generate and History Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="generate" className="flex items-center space-x-2">
              <Sparkles className="w-4 h-4" />
              <span>Generate Impression</span>
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center space-x-2">
              <History className="w-4 h-4" />
              <span>History ({history.length})</span>
            </TabsTrigger>
          </TabsList>

          {/* Generate Tab */}
          <TabsContent value="generate">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Input Section */}
              <Card className="shadow-xl border-0 bg-white/95 backdrop-blur">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Stethoscope className="w-5 h-5 text-blue-600" />
                    <span>Radiology Findings</span>
                  </CardTitle>
                  <CardDescription>Enter your radiology findings below</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Textarea
                    placeholder="Enter your radiology findings here... 

Example:
- Chest X-ray shows clear lung fields bilaterally
- No acute cardiopulmonary abnormalities
- Heart size within normal limits
- No pleural effusion or pneumothorax"
                    value={findings}
                    onChange={(e) => setFindings(e.target.value)}
                    className="min-h-[300px] medical-focus medical-transition"
                    disabled={isGenerating}
                  />

                  <Button
                    onClick={generateImpression}
                    disabled={isGenerating || !findings.trim()}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 medical-transition"
                  >
                    {isGenerating ? (
                      <>
                        <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                        Generating Impression...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 mr-2" />
                        Generate AI Impression
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Output Section */}
              <Card className="shadow-xl border-0 bg-white/95 backdrop-blur">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center space-x-2">
                        <Sparkles className="w-5 h-5 text-blue-600" />
                        <span>AI-Generated Impression</span>
                      </CardTitle>
                      <CardDescription>Professional radiology impression</CardDescription>
                      {lastGeneratedAt && (
                        <div className="flex items-center space-x-1 mt-2 text-sm text-gray-500">
                          <Clock className="w-4 h-4" />
                          <span>
                            Last generated: {lastGeneratedAt.toLocaleDateString()} at{" "}
                            {lastGeneratedAt.toLocaleTimeString()}
                          </span>
                        </div>
                      )}
                    </div>
                    {impression && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => copyToClipboard(impression)}
                        className="text-blue-600 border-blue-600 hover:bg-blue-50 bg-transparent"
                      >
                        <Copy className="w-4 h-4 mr-1" />
                        Copy
                      </Button>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  {impression ? (
                    <div className="space-y-4">
                      {/* Text Formatting Buttons */}
                      <div className="flex flex-wrap gap-2 p-3 bg-gray-50 rounded-lg border">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => formatText("Bold")}
                          className="h-8 px-2 hover:bg-blue-50"
                          title="Bold"
                        >
                          <Bold className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => formatText("Italic")}
                          className="h-8 px-2 hover:bg-blue-50"
                          title="Italic"
                        >
                          <Italic className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => formatText("Underline")}
                          className="h-8 px-2 hover:bg-blue-50"
                          title="Underline"
                        >
                          <Underline className="w-4 h-4" />
                        </Button>
                        <div className="w-px h-6 bg-gray-300 mx-1"></div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => formatText("Align Left")}
                          className="h-8 px-2 hover:bg-blue-50"
                          title="Align Left"
                        >
                          <AlignLeft className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => formatText("Align Center")}
                          className="h-8 px-2 hover:bg-blue-50"
                          title="Align Center"
                        >
                          <AlignCenter className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => formatText("Align Right")}
                          className="h-8 px-2 hover:bg-blue-50"
                          title="Align Right"
                        >
                          <AlignRight className="w-4 h-4" />
                        </Button>
                        <div className="w-px h-6 bg-gray-300 mx-1"></div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => formatText("Bullet List")}
                          className="h-8 px-2 hover:bg-blue-50"
                          title="Bullet List"
                        >
                          <List className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => formatText("Numbered List")}
                          className="h-8 px-2 hover:bg-blue-50"
                          title="Numbered List"
                        >
                          <ListOrdered className="w-4 h-4" />
                        </Button>
                      </div>

                      <Textarea
                        id="impression-text"
                        value={impression}
                        onChange={(e) => setImpression(e.target.value)}
                        className="min-h-[300px] font-mono text-sm bg-gray-50 border-gray-200"
                        placeholder="Your AI-generated impression will appear here..."
                      />

                      {tokenUsage && (
                        <div className="bg-blue-50 rounded-lg p-4">
                          <h4 className="font-semibold text-blue-900 mb-2">Token Usage</h4>
                          <div className="grid grid-cols-3 gap-4 text-sm">
                            <div>
                              <div className="text-blue-600 font-medium">Input Tokens</div>
                              <div className="text-blue-900">{tokenUsage.promptTokens}</div>
                            </div>
                            <div>
                              <div className="text-blue-600 font-medium">Output Tokens</div>
                              <div className="text-blue-900">{tokenUsage.completionTokens}</div>
                            </div>
                            <div>
                              <div className="text-blue-600 font-medium">Total Tokens</div>
                              <div className="text-blue-900 font-bold">{tokenUsage.totalTokens}</div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="min-h-[300px] flex items-center justify-center text-gray-500">
                      {isGenerating ? (
                        <div className="text-center">
                          <RefreshCw className="w-8 h-8 animate-spin mx-auto mb-4 text-blue-600" />
                          <p>AI is analyzing your findings...</p>
                        </div>
                      ) : (
                        <p>Your AI-generated impression will appear here</p>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history">
            <div className="space-y-6">
              {/* Search */}
              <Card>
                <CardContent className="p-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Search your impressions..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </CardContent>
              </Card>

              {/* History List */}
              {filteredHistory.length === 0 ? (
                <Card>
                  <CardContent className="text-center py-12">
                    <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">No Impressions Found</h3>
                    <p className="text-gray-600 mb-4">
                      {searchTerm ? "No impressions match your search." : "You haven't generated any impressions yet."}
                    </p>
                    <Button onClick={() => setActiveTab("generate")} className="bg-blue-600 hover:bg-blue-700">
                      Generate Your First Impression
                    </Button>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-6">
                  {filteredHistory.map((item) => (
                    <Card key={item.id} className="shadow-lg border-0 bg-white/95 backdrop-blur">
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <Clock className="w-5 h-5 text-blue-600" />
                            <div>
                              <CardTitle className="text-lg">
                                {new Date(item.createdAt).toLocaleDateString("en-US", {
                                  year: "numeric",
                                  month: "long",
                                  day: "numeric",
                                  hour: "2-digit",
                                  minute: "2-digit",
                                })}
                              </CardTitle>
                              <CardDescription>
                                {item.tokenUsage.totalTokens} tokens • ${item.tokenUsage.cost.toFixed(4)} • {item.model}
                              </CardDescription>
                            </div>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => copyToClipboard(item.impression)}
                            className="text-blue-600 border-blue-600 hover:bg-blue-50"
                          >
                            <Copy className="w-4 h-4 mr-1" />
                            Copy
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-2">Findings:</h4>
                          <div className="bg-gray-50 rounded-lg p-3 text-sm">{item.findings}</div>
                        </div>
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-2">AI Impression:</h4>
                          <div className="bg-blue-50 rounded-lg p-3 text-sm font-mono whitespace-pre-wrap">
                            {item.impression}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>

        {/* Pricing Popup */}
        <PricingPopup isOpen={showPricingPopup} onClose={() => setShowPricingPopup(false)} />
      </div>
    </div>
  )
}
