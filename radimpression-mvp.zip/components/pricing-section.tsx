"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Check, Star, Building, Users, Zap } from "lucide-react"

const plans = [
  {
    name: "Free Plan",
    price: "₹0",
    reports: "10",
    tokens: "10,000",
    icon: Zap,
    popular: false,
    features: ["10 AI-generated reports", "10,000 tokens included", "Basic support", "Standard processing speed"],
  },
  {
    name: "Starter",
    price: "₹199",
    reports: "100",
    tokens: "100,000",
    icon: Users,
    popular: true,
    features: [
      "100 AI-generated reports",
      "100,000 tokens included",
      "Priority support",
      "Faster processing",
      "Export to PDF",
    ],
  },
  {
    name: "Pro",
    price: "₹399",
    reports: "300",
    tokens: "300,000",
    icon: Star,
    popular: false,
    features: [
      "300 AI-generated reports",
      "300,000 tokens included",
      "Premium support",
      "Fastest processing",
      "Advanced templates",
      "Custom branding",
    ],
  },
  {
    name: "Clinic Plan",
    price: "₹999",
    reports: "1,000",
    tokens: "1,000,000",
    icon: Building,
    popular: false,
    features: [
      "1,000 AI-generated reports",
      "1,000,000 tokens included",
      "Dedicated support",
      "Multi-user access",
      "API integration",
      "Custom workflows",
      "Priority processing",
    ],
  },
]

interface PricingSectionProps {
  showAsPopup?: boolean
  onClose?: () => void
}

export function PricingSection({ showAsPopup = false, onClose }: PricingSectionProps) {
  const handleContactUs = () => {
    // You can replace this with your actual contact method
    window.open("mailto:support@radimpression.com?subject=Upgrade Plan Request", "_blank")
  }

  const content = (
    <div className="space-y-8">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Choose Your Plan</h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Select the perfect plan for your radiology practice. All plans include AI-powered impression generation with
          professional accuracy.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {plans.map((plan, index) => (
          <Card
            key={index}
            className={`relative shadow-lg border-0 bg-white/95 backdrop-blur hover:shadow-xl transition-all duration-300 ${
              plan.popular ? "ring-2 ring-blue-600 scale-105" : ""
            }`}
          >
            {plan.popular && (
              <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white px-4 py-1">
                Most Popular
              </Badge>
            )}

            <CardHeader className="text-center pb-4">
              <div
                className={`w-12 h-12 mx-auto mb-4 rounded-full flex items-center justify-center ${
                  plan.popular ? "bg-blue-600" : "bg-gray-100"
                }`}
              >
                <plan.icon className={`w-6 h-6 ${plan.popular ? "text-white" : "text-gray-600"}`} />
              </div>

              <CardTitle className="text-xl font-bold text-gray-900">{plan.name}</CardTitle>
              <div className="mt-2">
                <span className="text-3xl font-bold text-gray-900">{plan.price}</span>
                {plan.price !== "₹0" && <span className="text-gray-600">/month</span>}
              </div>
            </CardHeader>

            <CardContent className="space-y-4">
              <div className="text-center space-y-2">
                <div className="bg-blue-50 rounded-lg p-3">
                  <div className="text-sm text-blue-600 font-medium">Included Reports</div>
                  <div className="text-2xl font-bold text-blue-900">{plan.reports}</div>
                </div>
                <div className="bg-gray-50 rounded-lg p-3">
                  <div className="text-sm text-gray-600 font-medium">Approx. Tokens</div>
                  <div className="text-lg font-bold text-gray-900">{plan.tokens}</div>
                </div>
              </div>

              <ul className="space-y-2">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center text-sm">
                    <Check className="w-4 h-4 text-green-500 mr-2 flex-shrink-0" />
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button
                onClick={handleContactUs}
                className={`w-full mt-6 ${
                  plan.popular
                    ? "bg-blue-600 hover:bg-blue-700 text-white"
                    : "bg-gray-100 hover:bg-gray-200 text-gray-900"
                }`}
              >
                {plan.price === "₹0" ? "Current Plan" : "Contact Us"}
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="text-center bg-blue-50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-blue-900 mb-2">Need a Custom Plan?</h3>
        <p className="text-blue-700 mb-4">
          For hospitals and large clinics, we offer custom enterprise solutions with unlimited tokens and dedicated
          support.
        </p>
        <Button
          onClick={handleContactUs}
          variant="outline"
          className="text-blue-600 border-blue-600 hover:bg-blue-50 bg-transparent"
        >
          Contact Sales Team
        </Button>
      </div>
    </div>
  )

  if (showAsPopup) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-white rounded-lg max-w-6xl w-full max-h-[90vh] overflow-y-auto">
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Upgrade Your Plan</h2>
              <Button variant="ghost" onClick={onClose} className="text-gray-500 hover:text-gray-700">
                ✕
              </Button>
            </div>
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
              <p className="text-red-800 font-medium">
                🚫 Your account has reached its usage limit. Please upgrade to continue generating impressions.
              </p>
            </div>
            {content}
          </div>
        </div>
      </div>
    )
  }

  return <div className="bg-white/50 rounded-lg p-8">{content}</div>
}
